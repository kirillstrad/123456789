export const PILLARS = [[5, 5], [11, 5], [5, 12.8], [11, 12.8]], TOMBS = [[3.2, 8], [12.7, 9.2]], CAGES = [[3, 14.5], [13.3, 5.7]];
export const OBSTACLES = [...PILLARS.map(([x, y]) => ({ x, y, r: .57 })), ...TOMBS.map(([x, y]) => ({ x, y, r: .85 })), ...CAGES.map(([x, y]) => ({ x, y, r: .65 }))];
export function isSolid(x, y) { return x < 1.7 || y < 1.7 || x > 16 || y > 16 || OBSTACLES.some(o => Math.hypot(x - o.x, y - o.y) < o.r + .24) || (Math.abs(y - 2.8) < .28 && Math.abs(x - 8) < .85); }
export function initialState() { return { x: 8, y: 12, fx: 0, fy: -1, time: 0, walkDistance: 0, moving: false, lamp: 100, cameraX: 8, cameraY: 12 }; }
export function interpolate(a, b, t) { const m = (x, y) => x + (y - x) * t; return { ...b, x: m(a.x, b.x), y: m(a.y, b.y), time: m(a.time, b.time), walkDistance: m(a.walkDistance, b.walkDistance), cameraX: m(a.cameraX, b.cameraX), cameraY: m(a.cameraY, b.cameraY) }; }
export class World {
    previous = initialState();
    current = initialState();
    reset() { this.current = initialState(); this.previous = { ...this.current }; }
    update(dt, input) { this.previous = { ...this.current }; const s = this.current; s.time += dt; const n = Math.hypot(input.x, input.y), oldX = s.x, oldY = s.y; s.moving = false; if (n > .001) {
        s.fx = input.x / n;
        s.fy = input.y / n;
        const dx = s.fx * dt * 1.65, dy = s.fy * dt * 1.65;
        if (!isSolid(s.x + dx, s.y))
            s.x += dx;
        if (!isSolid(s.x, s.y + dy))
            s.y += dy;
        const distance = Math.hypot(s.x - oldX, s.y - oldY);
        s.moving = distance > 1e-8;
        s.walkDistance += distance;
    } s.cameraX += (s.x - s.cameraX) * Math.min(1, dt * 6); s.cameraY += (s.y - s.cameraY) * Math.min(1, dt * 6); s.lamp = 100; }
    snapshot(alpha) { return interpolate(this.previous, this.current, alpha); }
}
