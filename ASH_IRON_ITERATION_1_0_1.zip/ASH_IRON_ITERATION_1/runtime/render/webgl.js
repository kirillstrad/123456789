const VS = `#version 300 es
layout(location=0) in vec2 position;out vec2 uv;void main(){uv=position*.5+.5;gl_Position=vec4(position,0.,1.);}`;
const LIGHT = `#version 300 es
precision highp float;in vec2 uv;out vec4 frag;uniform sampler2D scene;uniform sampler2D heroMask;uniform vec2 size;uniform vec2 lamp;uniform float time;uniform int count;uniform vec4 lights[24];void main(){vec2 p=vec2(uv.x,1.-uv.y)*size-.5;bool hero=texture(heroMask,uv).r>.5;vec2 delta=p-lamp;float radius=146.*65./94.*1.2,n=exp(-dot(delta,delta)/(2.*radius*radius)),l=.018+(hero?.065:.12)+n*.82*1.6*(1.+sin(time*2.2)*.035);for(int i=0;i<24;i++){if(i>=count)break;vec2 d=p-lights[i].xy;l+=exp(-dot(d,d)/(2.*lights[i].z*lights[i].z))*lights[i].w;}if(hero)l=max(.3,min(.8,l));float vign=max(.25,1.-pow((p.x-504.)/700.,2.)*.32-pow((p.y-360.)/600.,2.)*.2),warm=min(1.,n);vec3 c=texture(scene,uv).rgb*l*vign*(hero?1.:1.25)*(vec3(1.)+warm*vec3(.19,-.1,-.32));frag=vec4(clamp(c,0.,1.),1.);}`;
const AVG = `#version 300 es
precision highp float;in vec2 uv;out vec4 frag;uniform sampler2D lit;uniform vec2 size;uniform vec2 grid;void main(){vec2 cell=floor(vec2(uv.x,1.-uv.y)*grid),lo=cell*size/grid,hi=(cell+1.)*size/grid,base=floor(lo);vec3 sum=vec3(0.);float total=0.;for(int y=0;y<7;y++)for(int x=0;x<7;x++){vec2 p=base+vec2(float(x),float(y)),w=max(vec2(0.),min(p+1.,hi)-max(p,lo));float area=w.x*w.y;if(area>0.){sum+=texelFetch(lit,ivec2(int(p.x),int(size.y)-1-int(p.y)),0).rgb*area;total+=area;}}frag=vec4(sum/max(total,.00001),1.);}`;
const GLYPH = `#version 300 es
precision highp float;in vec2 uv;out vec4 frag;uniform sampler2D cells;uniform sampler2D atlas;uniform vec2 size;uniform vec2 grid;vec4 cellColor(ivec2 cell){if(cell.x<0||cell.y<0||cell.x>=int(grid.x)||cell.y>=int(grid.y))return vec4(0.);vec3 c=texelFetch(cells,ivec2(cell.x,int(grid.y)-1-cell.y),0).rgb;float l=dot(c,vec3(.2126,.7152,.0722))*255.;if(l<4.)return vec4(0.);float idx=clamp(floor(pow(l/150.,.66)*44.),1.,44.),fade=l<9.?(l-4.)/5.:1.;return vec4(clamp(floor(c*255.*1.62*fade+.5)/255.,0.,1.),idx);}float ink(float idx,vec2 local){if(local.x<0.||local.y<0.||local.x>=8.||local.y>=10.)return 0.;ivec2 p=ivec2(int(mod(idx,8.))*8+int(floor(local.x)),int(floor(idx/8.))*10+int(floor(local.y)));return texelFetch(atlas,ivec2(p.x,59-p.y),0).a;}void main(){vec2 top=vec2(uv.x,1.-uv.y),cell=floor(top*grid),local=fract(top*grid)*size/grid;vec4 cur=cellColor(ivec2(cell));float a=cur.a>0.?ink(cur.a,local):0.;vec4 prev=cellColor(ivec2(cell)-ivec2(0,1));float b=prev.a>0.?ink(prev.a,local+vec2(0.,size.y/grid.y)):0.;frag=vec4(cur.rgb*a+prev.rgb*b*(1.-a),1.);}`;
export class WebGLRenderer {
    canvas = document.createElement('canvas');
    gl;
    lighting;
    downsample;
    glyph;
    textures = [];
    fbos = [];
    vao;
    constructor() {
        this.canvas.width = 1008;
        this.canvas.height = 720;
        const gl = this.canvas.getContext('webgl2', { alpha: false, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: true });
        if (!gl)
            throw Error('WebGL2 unavailable');
        this.gl = gl;
        this.vao = gl.createVertexArray();
        gl.bindVertexArray(this.vao);
        const b = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, b);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
        gl.enableVertexAttribArray(0);
        gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
        this.lighting = this.program(LIGHT, ['scene', 'heroMask', 'size', 'lamp', 'time', 'count', 'lights[0]']);
        this.downsample = this.program(AVG, ['lit', 'size', 'grid']);
        this.glyph = this.program(GLYPH, ['cells', 'atlas', 'size', 'grid']);
        for (let i = 0; i < 5; i++) {
            let t = gl.createTexture();
            this.textures.push(t);
            gl.bindTexture(gl.TEXTURE_2D, t);
            for (const p of [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T])
                gl.texParameteri(gl.TEXTURE_2D, p, gl.CLAMP_TO_EDGE);
            for (const p of [gl.TEXTURE_MIN_FILTER, gl.TEXTURE_MAG_FILTER])
                gl.texParameteri(gl.TEXTURE_2D, p, gl.NEAREST);
        }
        for (const [i, w, h] of [[2, 1008, 720], [3, 196, 140]]) {
            gl.bindTexture(gl.TEXTURE_2D, this.textures[i]);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            const f = gl.createFramebuffer();
            this.fbos.push(f);
            gl.bindFramebuffer(gl.FRAMEBUFFER, f);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.textures[i], 0);
            if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE)
                throw Error('Framebuffer incomplete');
        }
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        const a = document.createElement('canvas');
        a.width = 64;
        a.height = 60;
        const c = a.getContext('2d');
        c.font = '6px monospace';
        c.textBaseline = 'top';
        c.fillStyle = '#fff';
        [...' .,:;i1tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW8&%@'].forEach((s, i) => c.fillText(s, i % 8 * 8, Math.floor(i / 8) * 10));
        this.upload(4, a);
    }
    program(fragment, names) { const gl = this.gl, compile = (type, code) => { const s = gl.createShader(type); gl.shaderSource(s, code); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
        throw Error(gl.getShaderInfoLog(s) || 'Shader compile failed'); return s; }, p = gl.createProgram(); gl.attachShader(p, compile(gl.VERTEX_SHADER, VS)); gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fragment)); gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS))
        throw Error(gl.getProgramInfoLog(p) || 'Shader link failed'); return { p, u: Object.fromEntries(names.map(n => [n, gl.getUniformLocation(p, n)])) }; }
    upload(i, c) { const gl = this.gl; gl.bindTexture(gl.TEXTURE_2D, this.textures[i]); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c); }
    bind(i, u) { const gl = this.gl; gl.activeTexture(gl.TEXTURE0 + u); gl.bindTexture(gl.TEXTURE_2D, this.textures[i]); }
    pass(p, f, w, h) { const gl = this.gl; gl.bindFramebuffer(gl.FRAMEBUFFER, f); gl.viewport(0, 0, w, h); gl.useProgram(p.p); gl.bindVertexArray(this.vao); }
    render(frame, target) { const gl = this.gl; if (gl.isContextLost())
        throw Error('WebGL2 context lost'); let t = performance.now(); this.upload(0, frame.scene); this.upload(1, frame.mask); this.pass(this.lighting, this.fbos[0], 1008, 720); this.bind(0, 0); this.bind(1, 1); const u = this.lighting.u; gl.uniform1i(u.scene, 0); gl.uniform1i(u.heroMask, 1); gl.uniform2f(u.size, 1008, 720); gl.uniform2f(u.lamp, ...frame.lamp); gl.uniform1f(u.time, frame.time); const lights = frame.lights.slice(0, 24), buf = new Float32Array(96); lights.forEach((l, i) => buf.set([l.x, l.y, l.r, l.power], i * 4)); gl.uniform1i(u.count, lights.length); gl.uniform4fv(u['lights[0]'], buf); gl.drawArrays(gl.TRIANGLES, 0, 6); const lightingMs = performance.now() - t; t = performance.now(); this.pass(this.downsample, this.fbos[1], 196, 140); this.bind(2, 0); gl.uniform1i(this.downsample.u.lit, 0); gl.uniform2f(this.downsample.u.size, 1008, 720); gl.uniform2f(this.downsample.u.grid, 196, 140); gl.drawArrays(gl.TRIANGLES, 0, 6); this.pass(this.glyph, null, 1008, 720); this.bind(3, 0); this.bind(4, 1); gl.uniform1i(this.glyph.u.cells, 0); gl.uniform1i(this.glyph.u.atlas, 1); gl.uniform2f(this.glyph.u.size, 1008, 720); gl.uniform2f(this.glyph.u.grid, 196, 140); gl.drawArrays(gl.TRIANGLES, 0, 6); target.drawImage(this.canvas, 0, 0); return { lightingMs, glyphMs: performance.now() - t }; }
}
